import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Benefits from './components/Benefits';
import HowItWorks from './components/HowItWorks';
import MiniAppPreview from './components/MiniAppPreview';
import AIMentor from './components/AIMentor';
import DemoSimulator from './components/DemoSimulator';
import Partners from './components/Partners';
import Pricing from './components/Pricing';
import KpiPreview from './components/KpiPreview';
import FinalCTA from './components/FinalCTA';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-ink-950">
      <Navbar />
      <main>
        <Hero />
        <Benefits />
        <HowItWorks />
        <MiniAppPreview />
        <DemoSimulator />
        <AIMentor />
        <Partners />
        <Pricing />
        <KpiPreview />
        <FinalCTA />
      </main>
      <Footer />
    </div>
  );
}
