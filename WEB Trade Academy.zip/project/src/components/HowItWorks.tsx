import { steps } from '../data';
import { SectionHeading } from './SectionHeading';
import TelegramButton from './TelegramButton';

export default function HowItWorks() {
  return (
    <section id="how" className="relative py-24 sm:py-28">
      <div className="pointer-events-none absolute inset-0 -z-10 bg-grid-faint [background-size:56px_56px] opacity-30 [mask-image:radial-gradient(60%_50%_at_50%_50%,#000,transparent)]" />
      <div className="container-px">
        <SectionHeading
          eyebrow="How it works"
          title="From zero to confident — in five steps"
          subtitle="The whole journey lives inside Telegram. Open the bot, pick a topic, and the system handles the rest."
        />

        <div className="mt-14 grid gap-4 md:grid-cols-2 lg:grid-cols-5">
          {steps.map((s, i) => {
            const Icon = s.icon;
            return (
              <div key={s.num} className="relative">
                <div className="group h-full rounded-2xl border border-white/5 bg-ink-850/70 p-5 shadow-card transition-all duration-300 hover:-translate-y-1 hover:border-gold-500/20">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-semibold text-gold-500">{s.num}</span>
                    <div className="grid h-10 w-10 place-items-center rounded-lg border border-white/10 bg-white/[0.03] text-gold-300">
                      <Icon className="h-5 w-5" />
                    </div>
                  </div>
                  <h3 className="mt-4 font-display text-base font-semibold text-white">{s.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-zinc-400">{s.desc}</p>
                </div>
                {i < steps.length - 1 && (
                  <div className="absolute -right-2 top-1/2 hidden -translate-y-1/2 text-gold-600/40 lg:block">
                    <svg viewBox="0 0 24 24" className="h-5 w-5 fill-current">
                      <path d="M8.6 5.6l6.4 6.4-6.4 6.4 1.4 1.4 7.8-7.8L10 4.2z" />
                    </svg>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="mt-12 flex justify-center">
          <TelegramButton size="lg" label="Start in Telegram" />
        </div>
      </div>
    </section>
  );
}
