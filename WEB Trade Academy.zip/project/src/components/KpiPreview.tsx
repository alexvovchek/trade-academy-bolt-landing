import { kpis, weakTopics, trafficSources } from '../data';
import { SectionHeading } from './SectionHeading';

export default function KpiPreview() {
  return (
    <section id="kpi" className="relative py-24 sm:py-28">
      <div className="container-px">
        <SectionHeading
          eyebrow="KPI / admin preview"
          title="Built-in analytics for operators & partners"
          subtitle="A live admin view of what matters — learners, completion, exam mastery and traffic. Mock data shown for demonstration."
        />

        {/* KPI cards */}
        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {kpis.map((k) => {
            const Icon = k.icon;
            return (
              <div
                key={k.label}
                className="rounded-2xl border border-white/5 bg-ink-850/70 p-5 shadow-card"
              >
                <div className="flex items-center justify-between">
                  <div className="grid h-10 w-10 place-items-center rounded-lg border border-white/10 bg-white/[0.03] text-gold-300">
                    <Icon className="h-5 w-5" />
                  </div>
                  <span className="rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] font-semibold text-emerald-400">
                    {k.delta}
                  </span>
                </div>
                <p className="mt-4 font-display text-2xl font-bold text-white">{k.value}</p>
                <p className="text-xs text-zinc-500">{k.label}</p>
              </div>
            );
          })}
        </div>

        {/* charts row */}
        <div className="mt-4 grid gap-4 lg:grid-cols-2">
          {/* weak topics */}
          <div className="rounded-2xl border border-white/5 bg-ink-850/70 p-6 shadow-card">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-base font-semibold text-white">Weak topics</h3>
              <span className="text-xs text-zinc-500">avg mastery across cohort</span>
            </div>
            <div className="mt-5 space-y-4">
              {weakTopics.map((t) => (
                <div key={t.topic}>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-zinc-300">{t.topic}</span>
                    <span className="font-mono text-xs text-zinc-500">{t.mastery}%</span>
                  </div>
                  <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-white/5">
                    <div
                      className={`h-full rounded-full ${
                        t.mastery < 50
                          ? 'bg-gradient-to-r from-wine-400 to-wine-600'
                          : 'bg-gradient-to-r from-gold-400 to-gold-600'
                      }`}
                      style={{ width: `${t.mastery}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* traffic sources */}
          <div className="rounded-2xl border border-white/5 bg-ink-850/70 p-6 shadow-card">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-base font-semibold text-white">Traffic sources</h3>
              <span className="text-xs text-zinc-500">last 30 days</span>
            </div>
            <div className="mt-5 flex h-4 overflow-hidden rounded-full">
              {trafficSources.map((s, i) => {
                const colors = [
                  'bg-gold-400',
                  'bg-gold-600',
                  'bg-wine-400',
                  'bg-wine-600',
                ];
                return (
                  <div
                    key={s.source}
                    className={colors[i]}
                    style={{ width: `${s.share}%` }}
                    title={`${s.source}: ${s.share}%`}
                  />
                );
              })}
            </div>
            <div className="mt-5 space-y-2.5">
              {trafficSources.map((s, i) => {
                const dot = ['bg-gold-400', 'bg-gold-600', 'bg-wine-400', 'bg-wine-600'][i];
                return (
                  <div key={s.source} className="flex items-center justify-between text-sm">
                    <span className="flex items-center gap-2 text-zinc-300">
                      <span className={`h-2.5 w-2.5 rounded-full ${dot}`} />
                      {s.source}
                    </span>
                    <span className="font-mono text-xs text-zinc-500">{s.share}%</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <p className="mt-6 text-center text-xs text-zinc-600">
          All figures are mock data for demonstration purposes.
        </p>
      </div>
    </section>
  );
}
