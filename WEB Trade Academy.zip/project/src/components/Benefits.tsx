import { benefits } from '../data';
import { SectionHeading } from './SectionHeading';

export default function Benefits() {
  return (
    <section id="benefits" className="relative py-24 sm:py-28">
      <div className="container-px">
        <SectionHeading
          eyebrow="Product benefits"
          title="Everything you need to actually learn Price Action"
          subtitle="Not another video dump. Trade Academy is a structured practice system — theory, missions, real charts and an AI mentor that adapts to you."
        />

        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {benefits.map((b) => {
            const Icon = b.icon;
            const isWine = b.accent === 'wine';
            return (
              <div
                key={b.title}
                className="group relative overflow-hidden rounded-2xl border border-white/5 bg-ink-850/70 p-6 shadow-card transition-all duration-300 hover:-translate-y-1 hover:border-white/10"
              >
                <div
                  className={`pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full blur-2xl transition-opacity duration-300 ${
                    isWine ? 'bg-wine-500/10 opacity-0 group-hover:opacity-100' : 'bg-gold-500/10 opacity-0 group-hover:opacity-100'
                  }`}
                />
                <div
                  className={`grid h-12 w-12 place-items-center rounded-xl border ${
                    isWine
                      ? 'border-wine-400/30 bg-wine-500/10 text-wine-200'
                      : 'border-gold-500/30 bg-gold-500/10 text-gold-300'
                  }`}
                >
                  <Icon className="h-6 w-6" />
                </div>
                <h3 className="mt-5 font-display text-lg font-semibold text-white">{b.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-zinc-400">{b.desc}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
