import { partnerFeatures } from '../data';
import { SectionHeading } from './SectionHeading';
import TelegramButton from './TelegramButton';

export default function Partners() {
  return (
    <section id="partners" className="relative py-24 sm:py-28">
      <div className="container-px">
        <SectionHeading
          eyebrow="Creators & partners"
          title="A premium channel for serious trading brands"
          subtitle="Trade Academy reaches an engaged, self-selecting audience of active traders — right inside Telegram. Integrate your brand, your content and your community."
        />

        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {partnerFeatures.map((f) => {
            const Icon = f.icon;
            return (
              <div
                key={f.title}
                className="group rounded-2xl border border-white/5 bg-ink-850/70 p-6 shadow-card transition-all duration-300 hover:-translate-y-1 hover:border-gold-500/20"
              >
                <div className="grid h-11 w-11 place-items-center rounded-xl border border-gold-500/30 bg-gold-500/10 text-gold-300">
                  <Icon className="h-5 w-5" />
                </div>
                <h3 className="mt-4 font-display text-base font-semibold text-white">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-zinc-400">{f.desc}</p>
              </div>
            );
          })}
        </div>

        {/* placement showcase strip */}
        <div className="mt-8 grid gap-4 rounded-2xl border border-white/5 bg-ink-850/50 p-6 sm:grid-cols-3">
          {[
            { tag: 'Course screen', desc: 'Sponsored lesson header', cta: 'Brand logo + tagline' },
            { tag: 'Mission transition', desc: 'Full-screen interstitial', cta: 'Video or static creative' },
            { tag: 'Exam results', desc: 'Celebration moment', cta: 'Co-branded badge' },
          ].map((p) => (
            <div key={p.tag} className="rounded-xl border border-white/5 bg-ink-900/60 p-4">
              <span className="rounded-md bg-gold-500/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-gold-300">
                {p.tag}
              </span>
              <p className="mt-3 text-sm font-medium text-zinc-200">{p.desc}</p>
              <p className="mt-1 text-xs text-zinc-500">{p.cta}</p>
            </div>
          ))}
        </div>

        <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <TelegramButton variant="ghost" size="lg" label="Become a partner" />
          <TelegramButton variant="gold" size="lg" label="Advertise with us" />
        </div>
      </div>
    </section>
  );
}
