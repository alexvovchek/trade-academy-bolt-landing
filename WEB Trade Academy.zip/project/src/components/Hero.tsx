import { ArrowRight, Sparkles, ShieldCheck } from 'lucide-react';
import TelegramButton from './TelegramButton';
import PriceChart from './PriceChart';
import { TELEGRAM_URL } from '../data';

function Ticker() {
  const items = [
    { s: 'XAU/USD', p: '2,418.30', d: '+0.82%', up: true },
    { s: 'EUR/USD', p: '1.0842', d: '-0.14%', up: false },
    { s: 'BTC/USDT', p: '67,910', d: '+2.41%', up: true },
    { s: 'GBP/JPY', p: '198.45', d: '+0.31%', up: true },
    { s: 'US30', p: '39,872', d: '+0.56%', up: true },
    { s: 'NAS100', p: '18,210', d: '-0.22%', up: false },
  ];
  const row = [...items, ...items];
  return (
    <div className="mask-fade-x overflow-hidden border-y border-white/5 bg-ink-900/60">
      <div className="flex w-max animate-ticker gap-8 py-2.5">
        {row.map((it, i) => (
          <div key={i} className="flex items-center gap-2 whitespace-nowrap px-2 text-xs">
            <span className="font-mono font-medium text-zinc-400">{it.s}</span>
            <span className="font-mono font-semibold text-zinc-100">{it.p}</span>
            <span className={it.up ? 'text-emerald-400' : 'text-wine-300'}>{it.d}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Hero() {
  return (
    <section id="top" className="relative overflow-hidden pt-28 sm:pt-32 lg:pt-40">
      {/* ambient glows */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute left-1/2 top-0 h-[480px] w-[820px] -translate-x-1/2 rounded-full bg-radial-gold blur-2xl" />
        <div className="absolute right-0 top-40 h-[360px] w-[520px] rounded-full bg-radial-wine blur-2xl" />
        <div className="absolute inset-0 bg-grid-faint [background-size:48px_48px] opacity-40 [mask-image:radial-gradient(70%_50%_at_50%_30%,#000,transparent)]" />
      </div>

      <div className="container-px">
        <div className="mx-auto max-w-3xl text-center">
          <span className="eyebrow animate-pulseGlow">
            <Sparkles className="h-3.5 w-3.5" />
            AI-Powered Trading Education
          </span>
          <h1 className="mt-6 font-display text-4xl font-extrabold leading-[1.05] tracking-tight text-white text-balance sm:text-6xl lg:text-7xl">
            Trade Academy
          </h1>
          <p className="mt-4 font-display text-xl font-semibold text-gold-300 sm:text-2xl">
            AI-тренер по Price Action
          </p>
          <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-zinc-400 sm:text-lg text-balance">
            Master Price Action through theory, interactive missions, real chart practice and an
            AI mentor — all inside a Telegram Mini App. No installs. No noise. Just deliberate
            practice that makes you a better trader.
          </p>

          <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <TelegramButton size="lg" label="Open Telegram Mini App" />
            <TelegramButton variant="ghost" size="lg" label="Start in Telegram" href={TELEGRAM_URL} />
          </div>

          <div className="mt-6 flex items-center justify-center gap-2 text-xs text-zinc-500">
            <ShieldCheck className="h-4 w-4 text-gold-500" />
            Free to start — no card, no token required
          </div>
        </div>

        {/* Trading room monitor visual */}
        <div className="relative mx-auto mt-16 max-w-5xl">
          <div className="absolute -inset-x-6 -top-6 -bottom-6 -z-10 rounded-[2rem] bg-gradient-to-b from-gold-500/10 to-transparent blur-2xl" />
          <div className="overflow-hidden rounded-2xl border border-white/10 bg-ink-900/80 shadow-card backdrop-blur">
            {/* window bar */}
            <div className="flex items-center justify-between border-b border-white/5 bg-ink-850/80 px-4 py-3">
              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded-full bg-wine-400/70" />
                <span className="h-3 w-3 rounded-full bg-gold-400/70" />
                <span className="h-3 w-3 rounded-full bg-emerald-400/70" />
                <span className="ml-3 font-mono text-xs text-zinc-500">trade-academy — XAU/USD · 15m</span>
              </div>
              <span className="hidden font-mono text-xs text-zinc-500 sm:block">Price Action · Live practice</span>
            </div>

            {/* chart area */}
            <div className="relative grid grid-cols-1 gap-0 lg:grid-cols-[1fr_220px]">
              <div className="relative p-4">
                <div className="mb-3 flex items-center justify-between">
                  <div>
                    <p className="font-mono text-sm font-semibold text-zinc-100">XAU/USD</p>
                    <p className="font-mono text-xs text-emerald-400">+0.82% · 2,418.30</p>
                  </div>
                  <div className="flex gap-1.5">
                    {['5m', '15m', '1H', '4H'].map((tf, i) => (
                      <span
                        key={tf}
                        className={`rounded-md px-2 py-1 font-mono text-[10px] ${
                          i === 1
                            ? 'bg-gold-500/15 text-gold-300'
                            : 'bg-white/[0.03] text-zinc-500'
                        }`}
                      >
                        {tf}
                      </span>
                    ))}
                  </div>
                </div>
                <PriceChart className="h-[220px] w-full sm:h-[260px]" />
              </div>

              {/* side panel — mission */}
              <div className="border-t border-white/5 bg-ink-850/60 p-4 lg:border-l lg:border-t-0">
                <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-gold-400">
                  Active mission
                </p>
                <p className="mt-2 text-sm font-semibold text-white">Mark the liquidity sweep</p>
                <p className="mt-1.5 text-xs leading-relaxed text-zinc-500">
                  Identify the sweep below the prior low, then mark the zone of interest.
                </p>
                <div className="mt-4 space-y-2">
                  {[
                    { l: 'Identify prior low', done: true },
                    { l: 'Mark sweep candle', done: true },
                    { l: 'Draw demand zone', done: false },
                  ].map((s) => (
                    <div
                      key={s.l}
                      className="flex items-center gap-2 rounded-lg border border-white/5 bg-white/[0.02] px-3 py-2"
                    >
                      <span
                        className={`grid h-4 w-4 place-items-center rounded-full text-[9px] ${
                          s.done ? 'bg-gold-500 text-ink-950' : 'border border-white/15 text-transparent'
                        }`}
                      >
                        ✓
                      </span>
                      <span className="text-xs text-zinc-300">{s.l}</span>
                    </div>
                  ))}
                </div>
                <button className="btn-gold mt-4 w-full py-2 text-xs">
                  Submit answer
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-16">
        <Ticker />
      </div>
    </section>
  );
}
