import { TELEGRAM_URL } from '../data';

export default function Footer() {
  return (
    <footer className="border-t border-white/5 bg-ink-950">
      <div className="container-px py-12">
        <div className="flex flex-col items-center justify-between gap-6 sm:flex-row">
          <div className="flex items-center gap-2.5">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-gold-300 to-gold-600 text-ink-950">
              <svg viewBox="0 0 24 24" className="h-4 w-4 fill-current" aria-hidden="true">
                <path d="M3 17l5-5 4 4 8-9 1 2-9 10-4-4-5 5z" />
              </svg>
            </span>
            <span className="font-display text-base font-bold text-white">
              Trade<span className="text-gold-400"> Academy</span>
            </span>
          </div>

          <nav className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-zinc-500">
            <a href="#benefits" className="hover:text-zinc-200">Benefits</a>
            <a href="#how" className="hover:text-zinc-200">How it works</a>
            <a href="#preview" className="hover:text-zinc-200">Mini App</a>
            <a href="#mentor" className="hover:text-zinc-200">AI Mentor</a>
            <a href="#pricing" className="hover:text-zinc-200">Pricing</a>
          </nav>

          <a
            href={TELEGRAM_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="font-mono text-sm text-gold-400 hover:text-gold-300"
          >
            t.me/Trade_Academy_Bot
          </a>
        </div>

        <div className="mt-8 border-t border-white/5 pt-6 text-center text-xs text-zinc-600">
          <p>
            © {new Date().getFullYear()} Trade Academy. Educational product only — not financial
            advice. All data shown is mock data for demonstration.
          </p>
        </div>
      </div>
    </footer>
  );
}
