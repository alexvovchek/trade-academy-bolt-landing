import { Check } from 'lucide-react';
import { plans } from '../data';
import { SectionHeading } from './SectionHeading';

export default function Pricing() {
  return (
    <section id="pricing" className="relative py-24 sm:py-28">
      <div className="container-px">
        <SectionHeading
          eyebrow="Pricing"
          title="Start free. Upgrade when you're ready."
          subtitle="Simple, transparent plans. Prices shown are placeholders — final pricing is set inside the Telegram Mini App."
        />

        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {plans.map((p) => {
            const featured = p.featured;
            const accentRing =
              p.accent === 'gold'
                ? 'hover:border-gold-500/40'
                : p.accent === 'wine'
                ? 'hover:border-wine-400/40'
                : 'hover:border-white/15';

            return (
              <div
                key={p.name}
                className={`relative flex flex-col rounded-2xl border p-6 shadow-card transition-all duration-300 hover:-translate-y-1 ${
                  featured
                    ? 'border-gold-500/40 bg-gradient-to-b from-gold-500/[0.08] to-ink-850/80 shadow-glow'
                    : `border-white/5 bg-ink-850/70 ${accentRing}`
                }`}
              >
                {featured && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-gold-300 to-gold-500 px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-ink-950">
                    Most popular
                  </span>
                )}
                <h3 className="font-display text-lg font-bold text-white">{p.name}</h3>
                <p className="mt-1 text-xs text-zinc-500">{p.tagline}</p>

                <div className="mt-5 flex items-baseline gap-1">
                  <span
                    className={`font-display text-3xl font-extrabold ${
                      p.accent === 'wine' ? 'text-wine-200' : p.accent === 'gold' ? 'gradient-text-gold' : 'text-white'
                    }`}
                  >
                    {p.price}
                  </span>
                  {p.period && <span className="text-sm text-zinc-500">{p.period}</span>}
                </div>

                <ul className="mt-5 flex-1 space-y-2.5">
                  {p.features.map((f) => (
                    <li key={f} className="flex items-start gap-2.5 text-sm text-zinc-300">
                      <Check
                        className={`mt-0.5 h-4 w-4 shrink-0 ${
                          p.accent === 'wine' ? 'text-wine-300' : 'text-gold-400'
                        }`}
                      />
                      {f}
                    </li>
                  ))}
                </ul>

                <a
                  href="#top"
                  className={`mt-6 inline-flex w-full items-center justify-center rounded-xl px-5 py-3 text-sm font-semibold transition-all duration-300 hover:-translate-y-0.5 ${
                    featured
                      ? 'btn-gold'
                      : p.accent === 'wine'
                      ? 'btn-wine'
                      : 'btn-ghost'
                  }`}
                >
                  {p.cta}
                </a>
              </div>
            );
          })}
        </div>

        <p className="mt-8 text-center text-xs text-zinc-600">
          Placeholder pricing for demonstration. No payment is processed on this site.
        </p>
      </div>
    </section>
  );
}
